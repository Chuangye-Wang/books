import unittest


class TestMath(unittest.TestCase):
    def test_add_1(self):
        self.assertEqual(1 + 1, 2)

    def test_subtract_1(self):
        self.assertEqual(1 - 1, 0)
