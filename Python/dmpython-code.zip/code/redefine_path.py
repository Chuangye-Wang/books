path = "/etc/hosts"

from os import *

print(path)
