# right:
def add_to_list(a_list=None):
    if a_list is None:
        a_list = []
    a_list.append(2)
    print(a_list)

add_to_list()
add_to_list()
add_to_list()
add_to_list()
