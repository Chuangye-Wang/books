a = 1

# `a + oops` will never work:
# Traceback (most recent call last):
#   File "variable_does_not_exist.py", line 8, in <module>
#     a + oops
# NameError: name 'oops' is not defined
a + oops
