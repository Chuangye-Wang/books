my_dict = {"pi": 3.14, "pi": "apple"}

# is this `3.14 * 5` or `"apple" * 5` ??
print(my_dict["pi"] * 5)
