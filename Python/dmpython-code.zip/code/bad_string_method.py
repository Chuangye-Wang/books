some_string = "ABC"
some_string.foo_bar()
